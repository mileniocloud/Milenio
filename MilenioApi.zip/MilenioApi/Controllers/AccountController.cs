﻿using MilenioApi.DAO;
using MilenioApi.Models;
using System.Net;
using System.Web.Http;
using WebApi.Jwt;
using MilenioApi.Action;

namespace MilenioApi.Controllers
{  
    [RoutePrefix("api/Account")]
    public class AccountController : ApiController
    {
        TokenController tk = new TokenController();

        #region Manejo Cuentas

       

        #endregion
                           
    }
}
